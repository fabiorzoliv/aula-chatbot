# Chatbot em Django — material de aula

Projeto didático para executar no GitHub Codespaces, sem instalar Python/Django no computador do laboratório.

## O que está incluído
- Aplicação Django do chatbot.
- Código Python comentado em português.
- Interface HTML/JavaScript e CSS.
- Banco SQLite e migração inicial.
- Material didático completo em `docs/MATERIAL_DIDATICO.md`.
- Guia de leitura do código em `docs/GUIA_LEITURA_DO_CODIGO.md`.
- Configuração `.devcontainer/devcontainer.json` para preparar o ambiente Codespaces automaticamente.

## Para o aluno: usando o ZIP fornecido pelo professor
1. Crie um repositório individual no GitHub.
2. Envie este ZIP pelo recurso **Add file > Upload files** e faça o commit.
3. Abra **Code > Codespaces > Create codespace**.
4. No terminal do Codespaces, descompacte o ZIP e copie os arquivos para a raiz do repositório, caso ainda não estejam lá:
   ```bash
   unzip Chatbot_Django_Codespaces_Revisado.zip
   cp -R chatbot_tratado_django/. .
   ```
   Se o ZIP tiver outro nome, substitua-o no comando. Se o projeto já estiver diretamente na raiz, pule essa etapa.
5. Execute:
   ```bash
   python -m pip install -r requirements.txt
   python manage.py check
   python manage.py migrate
   python manage.py runserver 0.0.0.0:8000
   ```
6. Abra a aba **Ports** e a porta `8000` no navegador.

## Preparação automática
Se os arquivos do projeto estiverem na raiz do repositório antes de criar o Codespace, a configuração `.devcontainer/devcontainer.json` instala as dependências e aplica as migrações na criação do ambiente. Depois, execute `python manage.py runserver 0.0.0.0:8000`.

## Nota para o professor
O ZIP deve ser extraído para que `manage.py`, `requirements.txt`, `.devcontainer/`, `chatbot/`, `chatbot_project/`, `templates/` e `static/` fiquem na raiz do repositório. O arquivo ZIP não deve ficar como única coisa dentro do repositório na hora de criar o Codespace se a intenção for usar a configuração automática.
